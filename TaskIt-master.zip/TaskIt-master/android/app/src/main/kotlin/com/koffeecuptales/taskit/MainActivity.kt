package com.koffeecuptales.taskit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
